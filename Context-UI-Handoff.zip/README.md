# Context UI export

## Start here

- **Context-UI-Standalone.html:** open this file in a modern desktop browser. It contains the interface, styles, scenario engine and scripts in one file. It does not require a build, installation or online fonts.
- **frontend/:** the editable multi-file source. Enter that folder and run `python3 -m http.server 8780 --directory dist`, then open http://localhost:8780.
- **Context-UI-Agent-Prompt.md:** ready-to-paste instructions for the next agent, including visual direction, architecture, state rules and acceptance criteria.
- **Context-Demo-Flows.md:** both scenarios, precise presenter clicks and expected outcomes.
- **screenshots/:** actual captures of the interface, approval inbox, PR review and confirmed outcomes.
- **Context-2-Minute-Video-Guide.md:** the 120-second storyboard, narration and Claude instructions.

## Scope

This is the light, desktop-only frontend. It has two independent interactive scenarios, local state persistence, playback, on-demand details, separate approvals, and explicit simulated customer confirmations.

It has no backend or connected customer systems. Sample calls, orders, tickets, patches, check results and deployments are not live actions.

## Sharing with another agent

Give the agent this export, the screenshots and the agent prompt. Replace the prompt's final requested-change placeholder with your task. Keep simulation labels accurate and preserve the approval/confirmation gates.

The standalone HTML is a derivative export. Make future changes in `frontend/dist/`, then regenerate the single-file version so both stay consistent.

## Notes

- The desktop layout targets widths of at least 1180px. Phone layouts are intentionally excluded.
- Progress is stored locally in the browser. Use **Restart this scenario** before recording a fresh take.
- Browsers that restrict storage for local files can still run the demo; progress persistence may be unavailable. Use the local server for consistent browser behavior.
- The handoff excludes hosting credentials, Git metadata and private deployment configuration.
