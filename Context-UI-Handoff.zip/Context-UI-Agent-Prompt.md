# Context UI — ready-to-paste agent prompt

Use the following prompt with the exported frontend and screenshots. It applies to a coding agent, product designer, or frontend prototyping agent.

---

You are continuing **Context**, an existing desktop-only frontend prototype for handling customer problems from first report to confirmed recovery.

Start by reading the supplied frontend. Preserve the existing design and working interactions. Use the screenshots as visual references. Make the specific changes I request, keeping unrelated behavior intact.

## Objective

Demonstrate two workflows clearly:

1. A founder is away while separate agents handle a damaged-product review and a CV-upload support issue. The founder receives two concise decisions and approves them independently.
2. A customer issue moves through clarification, ownership, technical investigation, a proposed fix, human review, deployment verification, customer follow-up and confirmed recovery.

This is a frontend demonstration. All external records and actions are scripted sample data.

## Supplied files

- `frontend/dist/index.html`: the app shell, two scenario tabs, workflow board, playback controls and native detail dialog.
- `frontend/dist/styles.css`: the complete light desktop theme and layout.
- `frontend/dist/app.js`: scenario presentation, node details, conversation previews, approval inbox, sample code review and playback.
- `frontend/dist/demo-engine.js`: the state transitions and approval/confirmation gates. It also exports its functions for Node-based checks.
- `Context-UI-Standalone.html`: a single-file version with embedded styles and scripts.
- `screenshots/`: actual captures of the current frontend.
- `Context-Demo-Flows.md`: the scenarios, click sequence and expected states.

To run the source, enter `frontend/`, then run:

```sh
python3 -m http.server 8780 --directory dist
```

The supplied implementation has no package installation or build step. Reuse it. Port to another stack only when requested.

## Visual direction

- Desktop only, starting at 1180px wide. Do not add phone navigation or mobile layouts unless asked.
- Keep a clean, Jira-inspired light appearance: pale gray-blue canvas, white surfaces, navy text and restrained blue actions.
- Core colors: background `#F6F8FC`, text `#1C2E49`, primary action `#276BD1`, borders `#DCE3ED`. Amber marks pending decisions; green marks approved or customer-confirmed states, with explicit labels distinguishing them.
- Use the existing system font stack. Preserve legible typography, subtle shadows, consistent rounded corners and clear spacing.
- One main workflow canvas. A compact header contains the brand and the two scenario tabs. A small playback dock contains progress and actions.
- Keep conversation transcripts, evidence, assignment controls, PR details and approval summaries in on-demand dialogs.
- Avoid extra dashboards, KPI rows, permanent sidebars, decorative charts, giant headings, unnecessary explanation panels, sparkle icons, robot imagery, glowing effects or purple gradients.
- Color must have meaning. Pair it with text, icons or line styles. Maintain readable contrast and visible keyboard focus.

## Scenario 1: Founder overview

Two horizontal lanes advance in parallel:

- **Customer care:** Amazon review → verified customer/order context → proposed €79 replacement → founder decision → fulfillment → customer confirmation.
- **Engineering:** CV-upload ticket → customer clarification and diagnostic investigation → sample PR #184 → human decision → sample deployment → customer confirmation.

Seven engine steps:

0. Feedback received.
1. Gathering context.
2. Investigating.
3. Founder approval gate.
4. Execute approved actions in the simulation.
5. Wait for customer confirmation.
6. Both outcomes confirmed.

At step 3, open the WhatsApp-style approval inbox. The replacement and code fix require independent approvals. The technical approval requires acknowledgment of the sample patch, checks and delivery tradeoff.

Do not advance to execution while either approval is missing. At step 5, require the explicit **Simulate confirmations** action before showing both cases as confirmed.

## Scenario 2: Issue lifecycle

The diagram follows the customer-to-engineering-to-customer loop:

Report → clarify → assign/prioritize → investigate → prepare PR → review → deploy/verify → follow up → confirm recovery.

Nine engine steps:

0. Issue reported.
1. Clarification.
2. Ownership and priority.
3. Technical investigation.
4. Sample fix prepared.
5. Human approval gate.
6. Sample deployment verified.
7. Customer follow-up, awaiting confirmation.
8. Recovery confirmed.

The sample ticket is SUP-148. Related report SUP-151 comes from the same account: two reports, one affected account. The illustrative investigation links trace tr-cv-52, release v2.8.1, candidate commit c84e1 and PR #184. A sample release v2.8.2 represents deployment after approval.

Owner and priority can be reviewed in the assignment dialog. The follow-up dialog offers an email preview and an optional call script. Customer preference and operational urgency inform communication; associated revenue alone does not determine the channel.

## Interaction requirements

- Keep the labels **Founder overview**, **Issue lifecycle**, **Play demo**, **Next**, and **Restart this scenario** recognizable.
- Play advances automatically and pauses at approval and customer-confirmation gates.
- Next advances one permitted step. It must not bypass a gate.
- Opening a detail dialog, switching scenarios, or hiding the browser tab pauses playback.
- Each scenario has independent progress. Restart resets only the selected scenario.
- Use the existing engine as the source of truth. Keep state transitions separate from presentation.
- Changing routing after technical approval must invalidate that approval and require review again.
- Preserve local demo-state persistence and tolerate missing or invalid saved state.
- All visible controls must work. Keep native buttons, labeled fields, keyboard-accessible tabs, native dialogs and reduced-motion support.
- Avoid layout shifts when stages advance. The workflow must fit the intended desktop screen with the playback actions accessible.

## Product and evidence rules

- Approved, executed, deployed, delivered and customer-confirmed are distinct states.
- A suspected commit is not a confirmed root cause. Clearly label hypotheses, sample findings and verification.
- Sample PR checks are not tests run against a real customer repository.
- The Amazon scenario uses an existing verified contact and order match. Never imply a public username provides a telephone number or permission to call.
- Associated account revenue is not predicted loss or demonstrated revenue saved.
- Deduplicate accounts when several reports refer to the same problem.
- Do not fabricate live integrations, customer validation, business traction, actual calls or deployments.
- Do not add a backend, credentials, live payments, external messages or production code changes unless separately requested.

## Acceptance checks

1. Both scenarios can run from start to finish through the visible controls.
2. Each stops before execution until the required approval is recorded.
3. A replacement approval does not approve a PR.
4. PR approval requires the review acknowledgment.
5. Neither scenario reaches confirmed recovery without an explicit simulated customer confirmation.
6. Switching or restarting one scenario preserves the other scenario's state.
7. Detail dialogs match the current stage and do not claim unexecuted work has happened.
8. Recheck syntax and relevant engine behavior after logic changes. Visually inspect the desktop UI after layout changes.

When you finish, provide the updated frontend, a usable preview or exported file, a concise description of what changed, the checks performed, and any remaining limitations. Do not claim publication or video rendering unless the corresponding result exists.

My requested change is: **[Describe the next change here.]**
