# Context — two interactive desktop demos

A light, desktop-only frontend showing two customer-resolution workflows. All external actions and evidence are scripted demo data.

## Run

```sh
python3 -m http.server 8780 --directory dist
```

Open http://localhost:8780 on a desktop browser, 1180px or wider. No installation or build step is needed.

## Founder overview

Two cases run in parallel: a damaged-product Amazon review and a CV-upload support ticket. Play or Next advances through intake, context and investigation. Playback stops for two separate decisions. Approve the replacement, review and acknowledge the sample PR, then approve the fix. Continue to simulate execution. Explicitly simulate customer confirmations to reach the completed state.

The approval inbox resembles a WhatsApp conversation but is not connected to WhatsApp. The Amazon reviewer is matched to an existing verified sample contact; no contact details are inferred from a username.

## Issue lifecycle

Follow the CV-upload case through clarification, Jira ownership/priority, trace/release/commit investigation, draft PR, human review, deployment and customer follow-up. Playback stops before execution for PR review, and before closure for customer confirmation. Evidence, conversation transcripts, related reports, the sample patch and channel selection open on demand.

## Controls

- Scenario tabs switch between independent demos and pause playback.
- Play/Pause runs the prepared steps; Next advances one step.
- Restart resets only the current scenario.
- Click a workflow card to inspect its context.
- Approvals are separate from execution and customer-confirmed resolution.
- Demo progress and settings persist in this browser's local storage.

## Boundaries

There is no backend, authentication, model inference, actual call, refund, replacement order, Jira write, GitHub PR, deployment or customer message. Sample check results are not tests run against a real repository. `demo-engine.js` controls the frontend's approval and confirmation gates; those gates are not a production authorization system.

Frontend files: `index.html`, `styles.css`, `app.js`, and `demo-engine.js`. Phone layouts are intentionally out of scope.
